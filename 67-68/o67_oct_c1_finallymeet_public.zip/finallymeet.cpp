#include "finallymeet.h"

long long count_init(int N, int M, std::vector<int> U, std::vector<int> V) {
    return 0ll;
}