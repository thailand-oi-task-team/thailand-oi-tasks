#ifndef FINALLYMEET_H_INCLUDED
#define FINALLYMEET_H_INCLUDED

#include <vector>

long long count_init(int N, int M,
		     std::vector<int> U,
		     std::vector<int> V);

#endif
