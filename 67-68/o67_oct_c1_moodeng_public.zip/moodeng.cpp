#include "moodeng.h"

void search(int N, int M, int T) {
    // Example Usage:
    std::vector<std::vector<bool>> table(N);
    for (int i = 0; i < N; i++)
        table[i].resize(M, false);
    table[0][0] = true;
    table[0][1] = true;
    query(table);
}