#include <vector>

void search(int N, int M, int T);
bool query(std::vector<std::vector<bool>> table);