#include "goatpay.h"
#include <vector>

void plant_tree(int N, std::vector<int> U, std::vector<int> V, std::vector<int> W, std::vector<int> C) {
  // Your code here
}

int goat_pay(int u, int v, int x) {
  // Your code here
  return -1;
}

void update_edge(int id, int d) {
  // Your code here
}