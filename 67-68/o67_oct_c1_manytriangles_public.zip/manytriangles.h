#include <vector>

long long mincost_color(int C, std::vector<int> xs, std::vector<int> ys);