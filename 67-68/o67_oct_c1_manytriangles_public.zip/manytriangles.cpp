#include "manytriangles.h"

long long mincost_color(int C, std::vector<int> xs, std::vector<int> ys) {
    // Your implementation here...
}