#include "reunion.h"

namespace lemon {

int example_global_variable;
int example_global_function() { return 24; }
void lemon_init(int N, int M, std::vector<int> U, std::vector<int> V,
                std::vector<int> W, int u) {
    example_global_variable = N;
}

int lemon_move(int u) { return example_global_function(); }

} // namespace lemon