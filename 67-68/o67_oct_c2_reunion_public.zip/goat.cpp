#include "reunion.h"

namespace goat {

int example_global_variable;
int example_global_function() { return 42; }
void goat_init(int N, int M, std::vector<int> U, std::vector<int> V,
               std::vector<int> W, int u) {
    example_global_variable = N;
}

int goat_move(int u) { return example_global_function(); }

} // namespace goat