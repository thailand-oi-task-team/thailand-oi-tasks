void init(int N) {
    return;
}
void generateParticle(int L,int R,int P) {
    return;
}
long long countSize(int L,int R) {
    return 0;
}
int bestPartition(int L,int R) {
    return 0;
}