#include "OES.h"
#include <vector>

int machinepower(int N, std::vector<int> U, std::vector<int> V, std::vector<int> L) {
    return 0;
}