#include "marbletracks.h"
#include <vector>
#include <utility>

std::vector<int> observe(int N, int Q, std::vector<int> v, std::vector<std::tuple<int, int, int>> queries) {
  return {};
}
