#include "connection.h"
#include <vector>

int recommended_stations(int N, int M, std::vector<int> H, std::vector<int> A, std::vector<int> B) {
    return 0;
}