#include <vector>
#include "mountain.h"

void initialize(int N, std::vector<int> A, std::vector<int> C) {
	// Fill your code here
	return ;
}

long long race_cost(int S, int X) {
	// Fill your code here
	return 0ll;
}
