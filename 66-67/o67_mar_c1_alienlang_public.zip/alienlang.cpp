#include "alienlang.h"

int make_circuit(int n, int m, int p) {
    // edit this function...
    int k1 = add_machine(1, 2);
    int k2 = minus_machine(0, k1);
    return k2;
}