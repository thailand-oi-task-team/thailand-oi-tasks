int make_circuit(int n, int m, int p);
int add_machine(int src1, int src2);
int minus_machine(int src1, int src2);