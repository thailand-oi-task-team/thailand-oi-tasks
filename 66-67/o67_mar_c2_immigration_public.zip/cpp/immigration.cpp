#include "immigration.h"
#include <vector>

int immigration(int N, std::vector<int> A) {
    return 0;
}