#include "sailing.h"

int set_sail() {
  //Fill your code here
  return 0;
}