#ifndef __SAILLING_H_INCLUDED__
#define __SAILING_H_INCLUDED__

int set_sail();
bool sail_forward();
bool sail_backward();
void flag();

#endif