#include "volunteers.h"

void setup_battalion(int N, int M, int Q, std::vector<std::vector<int>> H) {}
int count_volunteers(int L, int R) { return R - L + 1; }