#include <vector>

std::vector<std::pair<int,int>> longest(int n);

bool find(int a, int b, int x);