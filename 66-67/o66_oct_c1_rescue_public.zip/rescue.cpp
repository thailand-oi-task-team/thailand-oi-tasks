#include "rescue.h"

void init_rescue(int N, int Q, std::vector<int> X, std::vector<int> Y)
{
}

int answer_query(int A, int B, int C, int D)
{
  return 0;
}

void cancel_request(int R)
{
}
