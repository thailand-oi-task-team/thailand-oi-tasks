#include <vector>

void init(int N, std::vector<int> A, std::vector<int> B, std::vector<int> W);

void toggle_hospital(int x);

void toggle_road(int x);

long long nearest_hospital(int x);