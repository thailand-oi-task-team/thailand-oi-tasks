#include <vector>

void kingdom(int N, int M, int Q, std::vector<int> u, std::vector<int> v,
             std::vector<int> s);

long long answer_query(int a);