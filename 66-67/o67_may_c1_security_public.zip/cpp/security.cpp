#include "security.h"

void kingdom(int N, int M, int Q, std::vector<int> u, std::vector<int> v,
             std::vector<int> s) {
    // implementation...
}

long long answer_query(int a) {
    // implementation...
    return 0ll;
}