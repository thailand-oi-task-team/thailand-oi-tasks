#ifndef TRIPLETS_H_INCLUDED
#define TRIPLETS_H_INCLUDED

#include <vector>

int count_triplets(int N,
		   std::vector<int> U,
		   std::vector<int> V,
		   std::vector<int> C);

#endif
