#include "triplets.h"
int count_triplets(int N, std::vector<int> U, std::vector<int> V, std::vector<int> C){
  return 0;
}
