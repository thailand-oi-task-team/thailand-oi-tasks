#ifndef UPANDDOWN_H_INCLUDED
#define UPANDDOWN_H_INCLUDED

#include <vector>
#include <bits/stdc++.h>

long long upanddown(int N,
		    std::vector<int> X);

#endif
