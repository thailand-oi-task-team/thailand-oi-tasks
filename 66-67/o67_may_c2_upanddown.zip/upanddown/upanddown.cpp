#include "upanddown.h"

long long upanddown(int N,
		    std::vector<int> X)
{
  return 0;
}
