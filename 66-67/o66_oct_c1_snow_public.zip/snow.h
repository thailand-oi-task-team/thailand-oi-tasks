#ifndef __SNOW_H_INCLUDED__
#define __SNOW_H_INCLUDED__

#include <vector>
std::vector<int> find_pair(int N, int M, std::vector<int>U, std::vector<int> V);
bool road_salt(std::vector<bool>road);

#endif
