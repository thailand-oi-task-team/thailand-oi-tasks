#include <vector>
#include "fatigue.h"
void initialize(int N, std::vector<int> A, std::vector<int> W){
    return;
}
void change_weight(int X, int V){
    return;
}
long long point_fatigue(std::vector<int> B){
    return 0;
}
long long interval_fatigue(std::vector<std::vector<int>> In){
    return 0;
}