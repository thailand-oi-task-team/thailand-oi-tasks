#include <vector>
void initialize(int N, std::vector<int> A, std::vector<int> W);
void change_weight(int X, int V);
long long point_fatigue(std::vector<int> B);
long long interval_fatigue(std::vector<std::vector<int>> In);