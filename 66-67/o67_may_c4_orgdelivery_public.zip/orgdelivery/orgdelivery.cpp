#include "orgdelivery.h"

std::vector<long long> mincost(int N, std::vector<int> P,
			       std::vector<long long> V, std::vector<int> W,
			       int Q,
			       std::vector<int> A, std::vector<int> B)
{
  std::vector<long long> output;
  for(int i=0; i<Q; i++)
    output.push_back(0);
  return output;
}
