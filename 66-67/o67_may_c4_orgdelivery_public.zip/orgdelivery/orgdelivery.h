#ifndef OGRDELIVERY_H_INCLUDED
#define ORGDELIVERY_H_INCLUDED

#include <vector>

std::vector<long long> mincost(int N, std::vector<int> P,
			       std::vector<long long> V, std::vector<int> W,
			       int Q,
			       std::vector<int> A, std::vector<int> B);

#endif
