#include "sum_product.h"

int sum_product(int n, std::vector<int> a){
	return 0;
}
