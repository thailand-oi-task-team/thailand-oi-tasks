#ifndef __SUM_PRODUCT_H_INCLUDED__
#define __SUM_PRODUCT_H_INCLUDED__

#include <vector>
int sum_product(int N, std::vector<int> A);

#endif
