#ifndef SECRETDEAL_H_INCLDED

#include <vector>

int make_deal(int N, int M, int K, int L,
	      std::vector<int> A,
	      std::vector<int> B,
	      std::vector<int> W);

#endif
