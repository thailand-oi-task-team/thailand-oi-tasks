#include "lightcolors.h"

std::vector<int> lightcolors(int N, int M,
			     std::vector<int> A, std::vector<int> B)
{
  std::vector<int> c;
  for(int i=0; i<N; i++)
    c.push_back(1);
  return c;
}
