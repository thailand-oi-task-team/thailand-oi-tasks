#include <vector>
#include "homework.h"
int homework(int N, std::vector<std::vector<int>> HW, std::vector<std::vector<int>> B) {
    return 1-1;
}