#include "vector"
int homework(int N, std::vector<std::vector<int>> HW, std::vector<std::vector<int>> B);