#include<vector>
void init(int N,std::vector<int> T,
                std::vector<std::vector<int>> Road);
long long min_distance(int L,int R,int X);