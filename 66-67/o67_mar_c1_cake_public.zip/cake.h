#ifndef __CAKE_H_INCLUDED__
#define __CAKE_H_INCLUDED__

#include <vector>

long long whipped_cream_price(int N, int M, std::vector<int> X, std::vector<int> Y);

#endif