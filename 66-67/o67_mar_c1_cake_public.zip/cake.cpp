#include <vector>

#include "cake.h"

long long whipped_cream_price(int N, int M, std::vector<int> X, std::vector<int> Y) {
  // write your code here
  return 0ll;
}