#include "convexhull.h"
#include <vector>

std::vector<int> convexhull(int n) {
    
}