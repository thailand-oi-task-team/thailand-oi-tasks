#include "convexhull.h"
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
 
struct Point {
    ll x, y, idx;
};

static Point p0;
 
static Point nextToTop(stack<Point> &S) {
    Point p = S.top();
    S.pop();
    Point res = S.top();
    S.push(p);
    return res;
}

static ll distSq(Point p1, Point p2) {
    return (p1.x - p2.x)*(p1.x - p2.x) + (p1.y - p2.y)*(p1.y - p2.y);
}

static int orientation(Point p, Point q, Point r) {
    ll val = (q.y - p.y) * (r.x - q.x) - (q.x - p.x) * (r.y - q.y);

    if (val == 0) return 0;
    return (val > 0)? 1: 2;
}

static int compare(const void *vp1, const void *vp2) {
   Point *p1 = (Point *)vp1;
   Point *p2 = (Point *)vp2;
 
   int o = orientation(p0, *p1, *p2);
   if (o == 0) return (distSq(p0, *p2) >= distSq(p0, *p1))? -1 : 1;
 
   return (o == 2)? -1: 1;
}

static vector<int> convexHull(vector<Point> points, int n) {

    if (n<=3) {
        vector<int> res;
        for (auto s : points) res.push_back(s.idx);
        return res;
    }

   int ymin = points[0].y, min = 0;
   for (int i = 1; i < n; i++) {
     int y = points[i].y;

     if ((y < ymin) || (ymin == y && points[i].x < points[min].x)) ymin = points[i].y, min = i;
   }

   swap(points[0], points[min]);

   p0 = points[0];
   qsort(&points[1], n-1, sizeof(Point), compare);
 
   for (int i=1; i<n-1; i++) {
       assert (orientation(p0, points[i], points[i+1]));
   }

   stack<Point> S;
   S.push(points[0]);
   S.push(points[1]);
   S.push(points[2]);

   for (int i = 3; i < n; i++) {
      while (S.size()>1 && orientation(nextToTop(S), S.top(), points[i]) != 2) S.pop();
      S.push(points[i]);
   }

   vector<int> res;

   while (!S.empty()) {
       Point p = S.top();
       res.push_back(p.idx);
       S.pop();
   }
   return res;
}

// convexhull graham's scan from https://www.geeksforgeeks.org/convex-hull-using-graham-scan/

static Point p[2005];
static int cnt=0;
static int N,Q;

bool is_critical(vector<int> v) {
    ++cnt;
    if (cnt>Q) {
        cout<<"Use function more than Q = "<<Q<<".\n";
        exit(0);
    }
    sort(v.begin(),v.end());

    for (int i=1; i<v.size(); ++i) {
        if (v[i]==v[i-1]) {
            cout<<"The element must be unique.\n";
            exit(0);
        }
        if (v[i]<0 || v[i]>=N) {
            cout<<"The value of point is incorrect.\n";
            exit(0);
        }
    }

    vector<Point> x;
    for (auto s : v) x.push_back(p[s]);
    vector<int> res=convexHull(x,x.size());
    sort(res.begin(),res.end());
    
    if (res.size()!=v.size()) return false;
    for (int i=0; i<res.size(); ++i) if (v[i]!=res[i]) return false;
    return true;
}

static bool comp(int A, int B) {
    return p[A].y<p[B].y;
}

vector<int> triangle(vector<int> v) {
    vector<Point> x;
    for (auto s : v) x.push_back(p[s]);
    vector<int> res=convexHull(x,x.size());
    if (res.size()!=3) {
        cout<<"The convexhull are not size of 3.\n";
        exit(0);
    }
    sort(res.begin(),res.end(),comp);
    return res;
}

int main() {
    assert(scanf("%d%d",&N,&Q)==2);

    for (int i=0; i<N; ++i) {
        int x,y;
        assert(scanf("%d%d",&x,&y)==2);
        p[i].x=x; p[i].y=y; p[i].idx=i;
    }

    vector<Point> X;
    for (int i=0; i<N; ++i) X.push_back(p[i]);

    vector<int> res2=convexHull(X,X.size());
    sort(res2.begin(),res2.end());

    vector<int> res=convexhull(N);
    sort(res.begin(),res.end());

    if (res.size()!=res2.size()) {
        cout<<"The size is wrong.\n";
        return 0;
    }

    for (int i=0; i<res.size(); ++i) {
        if (res[i]!=res2[i]) {
            cout<<"The element is wrong.\n";
            return 0;
        }
    }

    cout<<"The answer is Correct!\n";
    cout<<"Use function : "<<cnt<<" times\n";
}