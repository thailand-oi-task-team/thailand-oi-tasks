#include <vector>

std::vector<int> convexhull(int n);

bool is_critical(std::vector<int> v);

std::vector<int> triangle(std::vector<int> v);