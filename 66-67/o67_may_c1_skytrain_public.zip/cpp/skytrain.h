#include <vector>

long long min_total_cost(int N, int M, std::vector<int> A, std::vector<int> B, std::vector<int> W,
    long long K, int X, int Y);