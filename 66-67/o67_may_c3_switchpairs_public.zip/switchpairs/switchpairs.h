#ifndef SWITCHPAIRS_INCLUDED
#define SWITCHPAIRS_INCLUDED

#include <vector>

void solve(int N);

int control_switches(std::vector<int> V);

#endif
