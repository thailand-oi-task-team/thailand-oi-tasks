#include "switchpairs.h"

void solve(int N)
{
}
