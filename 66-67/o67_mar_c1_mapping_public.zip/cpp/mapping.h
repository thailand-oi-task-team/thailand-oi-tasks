#include <vector>
#include <utility>

std::vector<std::pair<int,int>> mapping(int n, int s);

bool send_signal(int x, int a, int b);