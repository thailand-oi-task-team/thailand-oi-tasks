#include "mapping.h"
#include <vector>
#include <utility>
using namespace std;

vector<pair<int,int>> mapping(int N, int S) {
    
    vector<pair<int,int>> Ans;
    for (int i=0; i<N-1; ++i) Ans.push_back(make_pair(i,i+1));

    return Ans;
}
