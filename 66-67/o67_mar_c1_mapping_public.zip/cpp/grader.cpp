#include <stdio.h>
#include <vector>
#include <utility>
#include <algorithm>
#include <assert.h>
#include "mapping.h"
using namespace std;

static int N,S,cntt,rnk[1005];
static long long dista[1005][1005];
static vector<pair<int,long long>> adja[1005];

void dfs(int x, int par, long long d, int st) {
    dista[st][x]=d;
    for (auto s : adja[x]) {
        if (s.first==par) continue;
        dfs(s.first,x,d+s.second,st);
    }
}

bool send_signal(int x, int a, int b) {
    assert(1<=x && x<=N); assert(1<=a && a<=N); assert(1<=b && b<=N);
    ++cntt;
    if (S==-1) {
        if (dista[x][a]<dista[x][b]) return true;
        else return false;
    } else {
        if (abs(rnk[a]-rnk[b])<=1) {
            if (dista[x][a]<dista[x][b]) return false;
            else return true;
        } else {
            if (dista[x][a]<dista[x][b]) return true;
            else return false;
        }
    }
}

int main() {

    assert(scanf("%d%d",&N,&S)==2);

    vector<pair<int,int>> input;

    for (int i=0; i<N-1; ++i) {
        int a,b;
        long long w;
        assert(scanf("%d%d%lld",&a,&b,&w)==3);
        adja[a].push_back(make_pair(b,w));
        adja[b].push_back(make_pair(a,w));
        input.push_back(make_pair(min(a,b),max(a,b)));
    }
    sort(input.begin(),input.end());

    for (int i=1; i<=N; ++i) dfs(i,0,0,i);

    if (S!=-1) {
        vector<pair<long long,int>> temp;
        for (int i=1; i<=N; ++i) temp.push_back(make_pair(dista[S][i],i));
        sort(temp.begin(),temp.end());
        for (int i=0; i<N; ++i) rnk[temp[i].second]=i+1;
    }

    vector<pair<int,int>> res=mapping(N,S);
    vector<pair<int,int>> v;

    for (auto s : res) v.push_back(make_pair(min(s.first,s.second),max(s.first,s.second)));
    sort(v.begin(),v.end());

    if (v.size()!=N-1) printf("The size is incorrect.");
    else {
        int w=0;
        for (int i=0; i<N-1; ++i) if (v[i].first!=input[i].first || v[i].second!=input[i].second) w=1;
        if (w==0) {
            printf("The answer is correct.\n");
            printf("The count of send_signal : %d",cntt);
        } else {
            printf("The answer is incorrect.");
        }
    }
}